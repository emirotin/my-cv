images_dir = 'assets/images'
http_images_path = '/images'
